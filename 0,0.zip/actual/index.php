<?php



/* 

start

main todo:
1. create database model
2. insert sample data
3. add methods for get_next_funny_content
4. methods for reactions
5. clickby script for setting trendsetters and update chains
6. simple backup for testing purposes
7. frontend proof-of-concept JS app
8. MVP with phonegap



**/ 

echo 'test';


// mockup and descripton, documentation link\

/*

catche?


założenia:
1. sa 2 podstawowe rodzaje chainów - pełny i trendsetterow
2. pierwszenstwo wyswietlania - najpierw grupy, potem pełny (nowe treści + ich indexowanie/ ocenianie)
3. każda dodana treść wpada do masterchaina




backend services

0. send funny content (user, chain_position)

'cron' jobs
1. analyze users_likes table
2. set trendsetters
3. update chains



**/ 


?>
