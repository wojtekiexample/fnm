-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: mariadb5.iq.pl
-- Generation Time: Dec 06, 2016 at 03:22 PM
-- Server version: 10.1.19-MariaDB-1~jessie
-- PHP Version: 5.6.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iexample_fnm`
--

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_1`
--

CREATE TABLE `actions_user_1` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `actions_user_1`
--

INSERT INTO `actions_user_1` (`id`, `publicationId`, `reaction`) VALUES
(1, 5, 1),
(2, 4, 2),
(3, 3, 1),
(4, 9, 3),
(5, 8, 3),
(6, 7, 3),
(7, 6, 2),
(8, 2, 3),
(9, 1, 2),
(10, 16, 2),
(11, 15, 3),
(12, 14, 2),
(13, 13, 3),
(14, 12, 1),
(15, 11, 2),
(16, 10, 3),
(17, 0, 2),
(18, -1, 1),
(19, -2, 2),
(20, -3, 3),
(21, -4, 2),
(22, -5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_2`
--

CREATE TABLE `actions_user_2` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `actions_user_2`
--

INSERT INTO `actions_user_2` (`id`, `publicationId`, `reaction`) VALUES
(1, 9, 3),
(2, 8, 2),
(3, 7, 3),
(4, 6, 3),
(5, 5, 3),
(6, 4, 3),
(7, 3, 3),
(8, 2, 3),
(9, 1, 2),
(10, 16, 3),
(11, 15, 3),
(12, 14, 2),
(13, 13, 2),
(14, 12, 3),
(15, 11, 3),
(16, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_3`
--

CREATE TABLE `actions_user_3` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `actions_user_3`
--

INSERT INTO `actions_user_3` (`id`, `publicationId`, `reaction`) VALUES
(1, 9, 3),
(2, 8, 3),
(3, 16, 1),
(4, 15, 2),
(5, 14, 3),
(6, 13, 2),
(7, 12, 1),
(8, 11, 3),
(9, 10, 3),
(10, 7, 3),
(11, 6, 3),
(12, 5, 3),
(13, 4, 2),
(14, 3, 3),
(15, 2, 1),
(16, 1, 3),
(17, 0, 2),
(18, -1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_4`
--

CREATE TABLE `actions_user_4` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `actions_user_4`
--

INSERT INTO `actions_user_4` (`id`, `publicationId`, `reaction`) VALUES
(1, 16, 2),
(2, 15, 3);

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_5`
--

CREATE TABLE `actions_user_5` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_6`
--

CREATE TABLE `actions_user_6` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_7`
--

CREATE TABLE `actions_user_7` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `actions_user_7`
--

INSERT INTO `actions_user_7` (`id`, `publicationId`, `reaction`) VALUES
(1, 16, 1),
(2, 15, 2),
(3, 14, 3),
(4, 54, 3),
(5, 53, 2),
(6, 52, 1),
(7, 51, 3),
(8, 50, 3),
(9, 49, 3),
(10, 48, 3),
(11, 6, 3);

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_8`
--

CREATE TABLE `actions_user_8` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_9`
--

CREATE TABLE `actions_user_9` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_10`
--

CREATE TABLE `actions_user_10` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_11`
--

CREATE TABLE `actions_user_11` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_12`
--

CREATE TABLE `actions_user_12` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_13`
--

CREATE TABLE `actions_user_13` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_14`
--

CREATE TABLE `actions_user_14` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_15`
--

CREATE TABLE `actions_user_15` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_16`
--

CREATE TABLE `actions_user_16` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_17`
--

CREATE TABLE `actions_user_17` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `actions_user_17`
--

INSERT INTO `actions_user_17` (`id`, `publicationId`, `reaction`) VALUES
(1, 54, 2),
(2, 53, 1),
(3, 52, 3),
(4, 51, 2),
(5, 50, 3),
(6, 49, 1),
(7, 48, 2),
(8, 47, 3),
(9, 46, 1),
(10, 45, 2);

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_18`
--

CREATE TABLE `actions_user_18` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_19`
--

CREATE TABLE `actions_user_19` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_20`
--

CREATE TABLE `actions_user_20` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actions_user_21`
--

CREATE TABLE `actions_user_21` (
  `id` int(11) NOT NULL,
  `publicationId` int(11) DEFAULT NULL,
  `reaction` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `funnyContent`
--

CREATE TABLE `funnyContent` (
  `id` int(11) NOT NULL,
  `createdTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ownerId` int(11) DEFAULT NULL,
  `fcTitle` text,
  `fcContent` text,
  `likes` int(11) DEFAULT NULL,
  `bans` int(11) DEFAULT NULL,
  `ignores` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `funnyContent`
--

INSERT INTO `funnyContent` (`id`, `createdTimestamp`, `ownerId`, `fcTitle`, `fcContent`, `likes`, `bans`, `ignores`) VALUES
(1, '2016-11-23 22:03:04', 1, 'miejsce dla inwalidow', '    &lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/6b95c2d2318d67ffa0ef2ee07c19269a.jpg&quot; alt=&quot;Miejsce dla inwalidĂłw&quot;&gt;', NULL, NULL, NULL),
(2, '2016-11-23 22:04:10', 1, 'UJÄCIA TAK PERFEKCYJNE, ĹťE AĹť MIĹO NA NIE POPATRZEÄ', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/d5a55e2bce9706a3ce3332e2e08e0c20.jpg&quot; alt=&quot;UjÄcia tak perfekcyjne, Ĺźe aĹź miĹo na nie popatrzeÄ&quot; class=&quot;gallery&quot;&gt;', NULL, NULL, NULL),
(3, '2016-11-23 22:04:30', 1, 'NIEZWYKLE RZADKI GATUNEK', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/7f62bc7d59e31e63521fddef14bf4eab.jpg&quot; alt=&quot;Niezwykle rzadki gatunek&quot;&gt;', NULL, NULL, NULL),
(4, '2016-11-23 22:05:05', 1, 'JEDEN PROSTY SPOSĂB', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/7977a54ea69953e8a8eef7d3ec9d0c04.jpg&quot; alt=&quot;Jeden prosty sposĂłb&quot;&gt;', NULL, NULL, NULL),
(5, '2016-11-23 22:05:41', 1, 'PETA', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/059542d91c94d6655423f81ba9a5de7f.jpg&quot; alt=&quot;PETA&quot;&gt;', NULL, NULL, NULL),
(6, '2016-11-23 22:12:25', 234, 'heheszkirrwer', '&lt;img src=&quot;http://static.polityka.pl/_resource/res/path/57/e5/57e50f13-053e-4e42-8178-f7f6595cc443_900x&quot;&gt;', NULL, NULL, NULL),
(7, '2016-11-23 22:12:26', 234, 'heheszkirrwer', '&lt;img src=&quot;http://static.polityka.pl/_resource/res/path/57/e5/57e50f13-053e-4e42-8178-f7f6595cc443_900x&quot;&gt;', NULL, NULL, NULL),
(8, '2016-11-23 22:12:27', 234, 'heheszkirrwer', '&lt;img src=&quot;http://static.polityka.pl/_resource/res/path/57/e5/57e50f13-053e-4e42-8178-f7f6595cc443_900x&quot;&gt;', NULL, NULL, NULL),
(9, '2016-11-23 22:12:29', 234, 'heheszkirrwer', '&lt;img src=&quot;http://static.polityka.pl/_resource/res/path/57/e5/57e50f13-053e-4e42-8178-f7f6595cc443_900x&quot;&gt;', NULL, NULL, NULL),
(10, '2016-11-24 00:45:54', 1, 'Jak', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/mhwY98ZtT394I39CxSuCvCvVyxwCj7WJ.jpg&quot; alt=&quot;Jak &quot;&gt;', NULL, NULL, NULL),
(11, '2016-11-24 00:46:17', 1, 'MEMY PO MECZU LEGIA VS BORUSSIA', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/7c15a8deb6de07372fb7aabf78c75846.jpg&quot; alt=&quot;Memy po meczu Legia vs  Borussia - I wtedy ja mu mĂłwiÄ: weĹş cierzniaka, jest w lepszej formie&quot; class=&quot;gallery&quot;&gt;', NULL, NULL, NULL),
(12, '2016-11-24 00:46:40', 1, 'ĹťYCIE Z PIESEĹEM', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/19ef113a8d00bb9e1ee0813ed14596ee.jpg&quot; alt=&quot;Ĺťycie z pieseĹem&quot;&gt;', NULL, NULL, NULL),
(13, '2016-11-24 00:47:03', 1, 'PIES NIE WIE CO ZROBIÄ', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/8565c1058954590d5d8d721b6211d318.jpg&quot; alt=&quot;Pies nie wie co zrobiÄ&quot;&gt;', NULL, NULL, NULL),
(14, '2016-11-24 00:47:37', 1, 'TO BÄDZIE MĂJ ROK', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/a02624d73c3225c610071892312d7b31.jpg&quot; alt=&quot;To bÄdzie mĂłj rok&quot;&gt;', NULL, NULL, NULL),
(15, '2016-11-24 00:47:56', 1, 'NAJLEPSZA KOBIETA NA ĹWIECIE', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/3bf1a122f093bf537c17c39da86ebfef.jpg&quot; alt=&quot;Najlepsza kobieta na Ĺwiecie&quot;&gt;', NULL, NULL, NULL),
(16, '2016-11-24 00:48:22', 1, 'LORD VOLDEMORT', '&lt;img src=&quot;http://i1.kwejk.pl/k/obrazki/2016/11/bc6cd14056272333d2e8e67dbff33d41.jpg&quot; alt=&quot;Lord Voldemort&quot;&gt;', NULL, NULL, NULL),
(17, '2016-11-29 19:31:33', 234, 'hszkii', 'smieszki nisniensi', NULL, NULL, NULL),
(18, '2016-11-29 19:31:35', 234, 'hszkii2', 'smieszki nisniensi', NULL, NULL, NULL),
(19, '2016-11-29 19:31:39', 234, 'hszkii2432', 'smieszki nisniensidawed', NULL, NULL, NULL),
(20, '2016-11-29 19:32:11', 234, 'smieszki', 'heszkicvs', NULL, NULL, NULL),
(21, '2016-11-29 19:32:13', 234, 'smieszki2', 'heszkicvs22', NULL, NULL, NULL),
(22, '2016-11-29 19:32:15', 234, 'smieszki233', 'heszkicvs2244', NULL, NULL, NULL),
(23, '2016-11-29 19:32:18', 234, 'smieszki23313', 'heszkicvs224443', NULL, NULL, NULL),
(24, '2016-11-29 19:33:13', 234, 'next', 'fsdfsrgare', NULL, NULL, NULL),
(25, '2016-11-29 19:33:15', 234, 'next2', 'fsdfsrgare2', NULL, NULL, NULL),
(26, '2016-11-29 19:33:17', 234, 'next23', 'fsdfsrgare23', NULL, NULL, NULL),
(27, '2016-11-29 19:33:18', 234, 'next234', 'fsdfsrgare234', NULL, NULL, NULL),
(28, '2016-11-29 19:33:34', 234, 'xent12', 'aaasd312', NULL, NULL, NULL),
(29, '2016-11-29 19:33:36', 234, '2xent12', 'aaasd3122', NULL, NULL, NULL),
(30, '2016-11-29 19:33:38', 234, '2xent1232', 'aaasd312212', NULL, NULL, NULL),
(31, '2016-11-29 19:33:40', 234, '2xent1232ds', 'aaasd312212ds', NULL, NULL, NULL),
(32, '2016-11-29 19:33:55', 234, 'nast21', 'dwafgeg', NULL, NULL, NULL),
(33, '2016-11-29 19:33:58', 234, 'nast212', 'dwafgeg212', NULL, NULL, NULL),
(34, '2016-11-29 19:34:00', 234, 'nast2122', 'dwafgeg2122', NULL, NULL, NULL),
(35, '2016-11-29 19:34:01', 234, 'nast21221', 'dwafgeg21221', NULL, NULL, NULL),
(36, '2016-11-29 19:34:25', 234, 'bla1', 'blalbal', NULL, NULL, NULL),
(37, '2016-11-29 19:34:27', 234, 'bla12', 'blalbal2', NULL, NULL, NULL),
(38, '2016-11-29 19:34:28', 234, 'bla123', 'blalbal23', NULL, NULL, NULL),
(39, '2016-11-29 19:34:30', 234, 'bla1234', 'blalbal234', NULL, NULL, NULL),
(40, '2016-11-29 19:34:52', 2342, 'slowo', 'slowo', NULL, NULL, NULL),
(41, '2016-11-29 19:34:54', 2342, 'slowo2', 'slowo2', NULL, NULL, NULL),
(42, '2016-11-29 19:34:55', 2342, 'slowo22', 'slowo22', NULL, NULL, NULL),
(43, '2016-11-29 19:34:58', 2342, 'slowo221', 'slowo221', NULL, NULL, NULL),
(44, '2016-11-29 19:35:14', 2342, 'obrazek', 'obrazek', NULL, NULL, NULL),
(45, '2016-11-29 19:35:15', 2342, 'obrazek2', 'obrazek2', NULL, NULL, NULL),
(46, '2016-11-29 19:35:17', 2342, 'obrazek23', 'obrazek23', NULL, NULL, NULL),
(47, '2016-11-29 19:35:19', 2342, 'obrazek234', 'obrazek234', NULL, NULL, NULL),
(48, '2016-11-29 19:35:21', 2342, 'obrazek2345', 'obrazek2345', NULL, NULL, NULL),
(49, '2016-11-29 19:35:22', 2342, 'obrazek2345', 'obrazek2345', NULL, NULL, NULL),
(50, '2016-11-29 19:35:36', 2342, 'video', 'video', NULL, NULL, NULL),
(51, '2016-11-29 19:35:38', 2342, '22video', 'video2', NULL, NULL, NULL),
(52, '2016-11-29 19:35:40', 2342, '22video2', 'video22', NULL, NULL, NULL),
(53, '2016-11-29 19:35:42', 2342, '22video21', 'video221', NULL, NULL, NULL),
(54, '2016-11-29 19:35:43', 2342, '22video213', 'video2213', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stream1`
--

CREATE TABLE `stream1` (
  `id` int(11) NOT NULL,
  `contentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stream1`
--

INSERT INTO `stream1` (`id`, `contentID`) VALUES
(1, 6),
(2, 6),
(3, 6),
(4, 6),
(5, 6),
(6, 6),
(7, 6),
(8, 6),
(9, 6),
(10, 6),
(11, 6),
(12, 6),
(13, 6),
(14, 6),
(15, 6),
(16, 6);

-- --------------------------------------------------------

--
-- Table structure for table `stream2`
--

CREATE TABLE `stream2` (
  `id` int(11) NOT NULL,
  `contentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stream2`
--

INSERT INTO `stream2` (`id`, `contentID`) VALUES
(1, 5),
(2, 5),
(3, 5),
(4, 5),
(5, 5),
(6, 5),
(7, 5),
(8, 5),
(9, 5),
(10, 5),
(11, 5),
(12, 5),
(13, 5),
(14, 5),
(15, 5),
(16, 5),
(17, 5),
(18, 5),
(19, 5);

-- --------------------------------------------------------

--
-- Table structure for table `stream3`
--

CREATE TABLE `stream3` (
  `id` int(11) NOT NULL,
  `contentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stream3`
--

INSERT INTO `stream3` (`id`, `contentID`) VALUES
(1, 7),
(2, 7),
(3, 7),
(4, 7),
(5, 7),
(6, 7),
(7, 7),
(8, 7),
(9, 7),
(10, 7),
(11, 7),
(12, 7),
(13, 7),
(14, 7),
(15, 7),
(16, 7),
(17, 7),
(18, 7),
(19, 7),
(20, 7),
(21, 7),
(22, 7),
(23, 7);

-- --------------------------------------------------------

--
-- Table structure for table `stream4`
--

CREATE TABLE `stream4` (
  `id` int(11) NOT NULL,
  `contentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stream4`
--

INSERT INTO `stream4` (`id`, `contentID`) VALUES
(1, 8),
(2, 8),
(3, 8),
(4, 8),
(5, 8),
(6, 8),
(7, 8),
(8, 8),
(9, 8),
(10, 8),
(11, 8),
(12, 8),
(13, 8),
(14, 8),
(15, 8),
(16, 8),
(17, 8),
(18, 8),
(19, 8),
(20, 8),
(21, 8),
(22, 8),
(23, 8),
(24, 8),
(25, 8),
(26, 8),
(27, 8);

-- --------------------------------------------------------

--
-- Table structure for table `stream5`
--

CREATE TABLE `stream5` (
  `id` int(11) NOT NULL,
  `contentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stream5`
--

INSERT INTO `stream5` (`id`, `contentID`) VALUES
(1, 9),
(2, 9),
(3, 9),
(4, 9),
(5, 9),
(6, 9),
(7, 9),
(8, 9),
(9, 9),
(10, 9),
(11, 9),
(12, 9),
(13, 9),
(14, 9),
(15, 9),
(16, 9),
(17, 9),
(18, 9),
(19, 9),
(20, 9),
(21, 9),
(22, 9),
(23, 9),
(24, 9),
(25, 9),
(26, 9),
(27, 9),
(28, 9),
(29, 9),
(30, 9),
(31, 9);

-- --------------------------------------------------------

--
-- Table structure for table `stream6`
--

CREATE TABLE `stream6` (
  `id` int(11) NOT NULL,
  `contentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stream6`
--

INSERT INTO `stream6` (`id`, `contentID`) VALUES
(1, 6),
(2, 6),
(3, 6),
(4, 6),
(5, 6),
(6, 6),
(7, 6),
(8, 6),
(9, 6),
(10, 6),
(11, 6),
(12, 6),
(13, 6),
(14, 6),
(15, 6),
(16, 6),
(17, 6),
(18, 6),
(19, 6),
(20, 6),
(21, 6),
(22, 6),
(23, 6),
(24, 6),
(25, 6),
(26, 6),
(27, 6),
(28, 6),
(29, 6),
(30, 6),
(31, 6),
(32, 6),
(33, 6),
(34, 6),
(35, 6);

-- --------------------------------------------------------

--
-- Table structure for table `stream7`
--

CREATE TABLE `stream7` (
  `id` int(11) NOT NULL,
  `contentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stream7`
--

INSERT INTO `stream7` (`id`, `contentID`) VALUES
(1, 7),
(2, 7),
(3, 7),
(4, 7),
(5, 7),
(6, 7),
(7, 7),
(8, 7),
(9, 7),
(10, 7),
(11, 7),
(12, 7),
(13, 7),
(14, 7),
(15, 7),
(16, 7),
(17, 7),
(18, 7),
(19, 7),
(20, 7),
(21, 7),
(22, 7),
(23, 7),
(24, 7),
(25, 7),
(26, 7),
(27, 7),
(28, 7),
(29, 7),
(30, 7),
(31, 7),
(32, 7),
(33, 7),
(34, 7),
(35, 7),
(36, 7),
(37, 7),
(38, 7),
(39, 7);

-- --------------------------------------------------------

--
-- Table structure for table `stream8`
--

CREATE TABLE `stream8` (
  `id` int(11) NOT NULL,
  `contentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stream8`
--

INSERT INTO `stream8` (`id`, `contentID`) VALUES
(1, 8),
(2, 8),
(3, 8),
(4, 8),
(5, 8),
(6, 8),
(7, 8),
(8, 8),
(9, 8),
(10, 8),
(11, 8),
(12, 8),
(13, 8),
(14, 8),
(15, 8),
(16, 8),
(17, 8),
(18, 8),
(19, 8),
(20, 8),
(21, 8),
(22, 8),
(23, 8),
(24, 8),
(25, 8),
(26, 8),
(27, 8),
(28, 8),
(29, 8),
(30, 8),
(31, 8),
(32, 8),
(33, 8),
(34, 8),
(35, 8),
(36, 8),
(37, 8),
(38, 8),
(39, 8),
(40, 8),
(41, 8),
(42, 8),
(43, 8);

-- --------------------------------------------------------

--
-- Table structure for table `stream9`
--

CREATE TABLE `stream9` (
  `id` int(11) NOT NULL,
  `contentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stream9`
--

INSERT INTO `stream9` (`id`, `contentID`) VALUES
(1, 9),
(2, 9),
(3, 9),
(4, 9),
(5, 9),
(6, 9),
(7, 9),
(8, 9),
(9, 9),
(10, 9),
(11, 9),
(12, 9),
(13, 9),
(14, 9),
(15, 9),
(16, 9),
(17, 9),
(18, 9),
(19, 9),
(20, 9),
(21, 9),
(22, 9),
(23, 9),
(24, 9),
(25, 9),
(26, 9),
(27, 9),
(28, 9),
(29, 9),
(30, 9),
(31, 9),
(32, 9),
(33, 9),
(34, 9),
(35, 9),
(36, 9),
(37, 9),
(38, 9),
(39, 9),
(40, 9),
(41, 9),
(42, 9),
(43, 9),
(44, 9),
(45, 9),
(46, 9),
(47, 9),
(48, 9),
(49, 9);

-- --------------------------------------------------------

--
-- Table structure for table `stream10`
--

CREATE TABLE `stream10` (
  `id` int(11) NOT NULL,
  `contentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stream10`
--

INSERT INTO `stream10` (`id`, `contentID`) VALUES
(1, 10),
(2, 10),
(3, 10),
(4, 10),
(5, 10),
(6, 10),
(7, 10),
(8, 10),
(9, 10),
(10, 10),
(11, 10),
(12, 10),
(13, 10),
(14, 10),
(15, 10),
(16, 10),
(17, 10),
(18, 10),
(19, 10),
(20, 10),
(21, 10),
(22, 10),
(23, 10),
(24, 10),
(25, 10),
(26, 10),
(27, 10),
(28, 10),
(29, 10),
(30, 10),
(31, 10),
(32, 10),
(33, 10),
(34, 10),
(35, 10),
(36, 10),
(37, 10),
(38, 10),
(39, 10),
(40, 10),
(41, 10),
(42, 10),
(43, 10),
(44, 10),
(45, 10),
(46, 10),
(47, 10),
(48, 10),
(49, 10),
(50, 10),
(51, 10),
(52, 10),
(53, 10),
(54, 10);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `createdTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `actionsCount` int(11) DEFAULT NULL,
  `userActionsTableName` text,
  `eMail` text,
  `likes` int(11) DEFAULT NULL,
  `bans` int(11) DEFAULT NULL,
  `ignores` int(11) DEFAULT NULL,
  `login` text,
  `passwordHash` text,
  `influenceIndex` int(11) DEFAULT NULL,
  `asignedTransetter` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `createdTimestamp`, `actionsCount`, `userActionsTableName`, `eMail`, `likes`, `bans`, `ignores`, `login`, `passwordHash`, `influenceIndex`, `asignedTransetter`) VALUES
(1, '2016-11-23 22:01:15', NULL, 'actions_user_1', 'sajanmaciej@gmail.com', NULL, NULL, NULL, 'sajan', '9743a66f914cc249efca164485a19c5c', NULL, NULL),
(2, '2016-11-24 00:21:19', NULL, 'actions_user_2', 'dfgbdfgbdf', NULL, NULL, NULL, 'bgbdfgb', 'b40baa80c2d00e855564ab329a386d19', NULL, NULL),
(3, '2016-11-24 00:21:27', NULL, 'actions_user_3', 'dfgbdfgbdf', NULL, NULL, NULL, 'bgbdfgb', 'b40baa80c2d00e855564ab329a386d19', NULL, NULL),
(4, '2016-11-24 01:21:48', NULL, 'actions_user_4', 'dfgbdfgbdf', NULL, NULL, NULL, 'bgbdfgb', 'b40baa80c2d00e855564ab329a386d19', NULL, NULL),
(5, '2016-11-24 01:21:50', NULL, 'actions_user_5', 'dfgbdfgbdf', NULL, NULL, NULL, 'bgbdfgb', 'b40baa80c2d00e855564ab329a386d19', NULL, NULL),
(6, '2016-11-28 22:12:27', NULL, 'actions_user_6', '33333', NULL, NULL, NULL, '3123123', '6884fb0f047aaf5a6ee36ee6d925fbc5', NULL, NULL),
(7, '2016-11-28 22:19:21', 10, 'actions_user_7', '333435', NULL, NULL, NULL, '3123134', '6884fb0f047aaf5a6ee36ee6d925fbc5', 12, NULL),
(8, '2016-11-28 22:12:33', NULL, 'actions_user_8', '333435', NULL, NULL, NULL, '3123134', '6884fb0f047aaf5a6ee36ee6d925fbc5', NULL, NULL),
(9, '2016-11-28 22:12:34', NULL, 'actions_user_9', '333435', NULL, NULL, NULL, '3123134', '6884fb0f047aaf5a6ee36ee6d925fbc5', NULL, NULL),
(10, '2016-11-28 22:12:34', NULL, 'actions_user_10', '333435', NULL, NULL, NULL, '3123134', '6884fb0f047aaf5a6ee36ee6d925fbc5', NULL, NULL),
(11, '2016-11-28 22:12:34', NULL, 'actions_user_11', '333435', NULL, NULL, NULL, '3123134', '6884fb0f047aaf5a6ee36ee6d925fbc5', NULL, NULL),
(12, '2016-11-28 22:12:34', NULL, 'actions_user_12', '333435', NULL, NULL, NULL, '3123134', '6884fb0f047aaf5a6ee36ee6d925fbc5', NULL, NULL),
(13, '2016-11-28 22:12:34', NULL, 'actions_user_13', '333435', NULL, NULL, NULL, '3123134', '6884fb0f047aaf5a6ee36ee6d925fbc5', NULL, NULL),
(14, '2016-11-28 22:12:35', NULL, 'actions_user_14', '333435', NULL, NULL, NULL, '3123134', '6884fb0f047aaf5a6ee36ee6d925fbc5', NULL, NULL),
(15, '2016-11-28 22:12:35', NULL, 'actions_user_15', '333435', NULL, NULL, NULL, '3123134', '6884fb0f047aaf5a6ee36ee6d925fbc5', NULL, NULL),
(16, '2016-11-28 22:12:36', NULL, 'actions_user_16', '333435', NULL, NULL, NULL, '3123134', '6884fb0f047aaf5a6ee36ee6d925fbc5', NULL, NULL),
(17, '2016-11-29 18:03:32', NULL, 'actions_user_17', 'sdfds', NULL, NULL, NULL, 'newtrend', '6971fbf9f6c2d051018afd5b17ca6b46', NULL, NULL),
(18, '2016-11-29 18:03:34', NULL, 'actions_user_18', 'sdfds', NULL, NULL, NULL, 'newtrend', '6971fbf9f6c2d051018afd5b17ca6b46', NULL, NULL),
(19, '2016-11-29 18:03:35', NULL, 'actions_user_19', 'sdfds', NULL, NULL, NULL, 'newtrend', '6971fbf9f6c2d051018afd5b17ca6b46', NULL, NULL),
(20, '2016-11-29 18:03:36', NULL, 'actions_user_20', 'sdfds', NULL, NULL, NULL, 'newtrend', '6971fbf9f6c2d051018afd5b17ca6b46', NULL, NULL),
(21, '2016-11-29 18:03:38', NULL, 'actions_user_21', 'sdfds', NULL, NULL, NULL, 'newtrend', '6971fbf9f6c2d051018afd5b17ca6b46', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions_user_1`
--
ALTER TABLE `actions_user_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_2`
--
ALTER TABLE `actions_user_2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_3`
--
ALTER TABLE `actions_user_3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_4`
--
ALTER TABLE `actions_user_4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_5`
--
ALTER TABLE `actions_user_5`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_6`
--
ALTER TABLE `actions_user_6`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_7`
--
ALTER TABLE `actions_user_7`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_8`
--
ALTER TABLE `actions_user_8`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_9`
--
ALTER TABLE `actions_user_9`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_10`
--
ALTER TABLE `actions_user_10`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_11`
--
ALTER TABLE `actions_user_11`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_12`
--
ALTER TABLE `actions_user_12`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_13`
--
ALTER TABLE `actions_user_13`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_14`
--
ALTER TABLE `actions_user_14`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_15`
--
ALTER TABLE `actions_user_15`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_16`
--
ALTER TABLE `actions_user_16`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_17`
--
ALTER TABLE `actions_user_17`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_18`
--
ALTER TABLE `actions_user_18`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_19`
--
ALTER TABLE `actions_user_19`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_20`
--
ALTER TABLE `actions_user_20`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `actions_user_21`
--
ALTER TABLE `actions_user_21`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `funnyContent`
--
ALTER TABLE `funnyContent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stream1`
--
ALTER TABLE `stream1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stream2`
--
ALTER TABLE `stream2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stream3`
--
ALTER TABLE `stream3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stream4`
--
ALTER TABLE `stream4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stream5`
--
ALTER TABLE `stream5`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stream6`
--
ALTER TABLE `stream6`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stream7`
--
ALTER TABLE `stream7`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stream8`
--
ALTER TABLE `stream8`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stream9`
--
ALTER TABLE `stream9`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stream10`
--
ALTER TABLE `stream10`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions_user_1`
--
ALTER TABLE `actions_user_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `actions_user_2`
--
ALTER TABLE `actions_user_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `actions_user_3`
--
ALTER TABLE `actions_user_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `actions_user_4`
--
ALTER TABLE `actions_user_4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `actions_user_5`
--
ALTER TABLE `actions_user_5`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_6`
--
ALTER TABLE `actions_user_6`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_7`
--
ALTER TABLE `actions_user_7`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `actions_user_8`
--
ALTER TABLE `actions_user_8`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_9`
--
ALTER TABLE `actions_user_9`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_10`
--
ALTER TABLE `actions_user_10`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_11`
--
ALTER TABLE `actions_user_11`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_12`
--
ALTER TABLE `actions_user_12`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_13`
--
ALTER TABLE `actions_user_13`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_14`
--
ALTER TABLE `actions_user_14`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_15`
--
ALTER TABLE `actions_user_15`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_16`
--
ALTER TABLE `actions_user_16`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_17`
--
ALTER TABLE `actions_user_17`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `actions_user_18`
--
ALTER TABLE `actions_user_18`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_19`
--
ALTER TABLE `actions_user_19`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_20`
--
ALTER TABLE `actions_user_20`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actions_user_21`
--
ALTER TABLE `actions_user_21`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `funnyContent`
--
ALTER TABLE `funnyContent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `stream1`
--
ALTER TABLE `stream1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `stream2`
--
ALTER TABLE `stream2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `stream3`
--
ALTER TABLE `stream3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `stream4`
--
ALTER TABLE `stream4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `stream5`
--
ALTER TABLE `stream5`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `stream6`
--
ALTER TABLE `stream6`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `stream7`
--
ALTER TABLE `stream7`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `stream8`
--
ALTER TABLE `stream8`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `stream9`
--
ALTER TABLE `stream9`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `stream10`
--
ALTER TABLE `stream10`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
