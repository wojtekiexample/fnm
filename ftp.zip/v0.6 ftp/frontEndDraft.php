<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>front</title>
<style type="text/css">
bady{background-color:#06F;}
*{font-family:Arial, Helvetica, sans-serif; font-size:10px;}
h1{font-size:12px; font-weight:bold;}
input{
	margin:5px;
	-moz-border-radius: 5px;
    -webkit-border-radius: 5px;}
.button{
	-moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    -moz-box-shadow: 0px 3px 9px rgba(0,0,0,0.5);
    -webkit-box-shadow: 0px 3px rgba(0,0,0,0.5);
    box-shadow: 0px 3px 9px rgba(0,0,0,0.5);
    border-radius: 5px;
    background-color: #10a010;
    cursor: pointer;
    display: inline-block;
    color: #FFF;
    padding: 5px;
    padding-left: 15px;
    padding-right: 15px;
	margin-top:15px;
	margin-bottom:15px;
	}

</style>


</head>
<script type="text/javascript" src="/js/SajanaJsonAjax.js" ></script>


<h1>Dodaj usera:</h1>
<form id="dadajUseraForm">
	login:<input id="dodajUseraLoginInput" type="text" /><br/>
	password:<input id="dodajUseraPasswordInput" type="password" /><br/>
    e-mail:<input id="dodajUseraEMailInput" type="email" /><br/>
</form>
<div class="button" id="dodajUseraBtn">Dodaj</div>

<h1>Dodaj coś śmiesznego:</h1>
<form id="dadajCosSmiesznegoForm">
	id:<input id="dadajCosSmiesznegoIdInput" type="number" /><br/>
	tytuł:<input id="dadajCosSmiesznegoTitleInput" type="text" /><br/>
    treść:<br/>
    <textarea id="dadajCosSmiesznegoContentInput">
    </textarea>
</form>
<div class="button" id="dadajCosSmiesznegoBtn">Dodaj</div>


<script type="text/javascript" src="js/frontEndDraft.js"></script>


<body>
</body>
</html>