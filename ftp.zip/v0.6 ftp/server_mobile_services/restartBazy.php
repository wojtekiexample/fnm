<?php
echo("przed require");



?>