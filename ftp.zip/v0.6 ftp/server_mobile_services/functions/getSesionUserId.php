<?php
session_start();
if (isset($_SESSION['fnmUserId'])){
	echo($_SESSION['fnmUserId']);
}
?>